# 🚀 Деплой на Vercel за 10 минут

## Предварительные условия

- GitHub аккаунт (или GitLab, Bitbucket)
- Vercel аккаунт (бесплатно)
- Проект на GitHub

---

## Этап 1: Подготовить GitHub репозиторий

### Вариант A: Если проекта ещё нет на GitHub

```bash
cd order-eat-repeat-main

# Инициализировать git
git init

# Добавить все файлы
git add .

# Первый коммит
git commit -m "Initial commit: order-eat-repeat app"

# Создать репозиторий на github.com и скопировать URL
# https://github.com/YOUR_USERNAME/order-eat-repeat

git remote add origin https://github.com/YOUR_USERNAME/order-eat-repeat.git
git branch -M main
git push -u origin main
```

### Вариант B: Если проект уже на GitHub

```bash
cd order-eat-repeat-main
git add .
git commit -m "chore: update for Vercel deployment"
git push origin main
```

---

## Этап 2: Создать Vercel проект

### Шаг 1: Войти на Vercel

1. Открыть [vercel.com](https://vercel.com)
2. Нажать "Sign Up" (если нет аккаунта)
3. Войти через GitHub

### Шаг 2: Создать новый проект

1. После входа → Dashboard
2. Нажать кнопку "Add New..." → "Project"
3. Выбрать репозиторий `order-eat-repeat` из списка
4. Если репо не видно:
   - Нажать "Adjust GitHub App Permissions"
   - Выбрать "All repositories" или конкретно `order-eat-repeat`
   - Сохранить

### Шаг 3: Настроить Build Settings

Vercel обычно автоматически определяет что это Vite проект.

Проверить:
- Framework Preset: `Vite` ✅
- Build Command: `npm run build` ✅
- Output Directory: `dist` ✅
- Install Command: `npm install` ✅

**Если что-то отличается, исправить вручную.**

---

## Этап 3: Добавить переменные окружения (важно!)

Firebase конфиги должны быть в переменных окружения, чтобы не попасть в публичный код.

### Найти Firebase конфиги

1. Открыть `firebase-applet-config.json` в проекте
2. Там есть все необходимые значения:
```json
{
  "apiKey": "AIzaSyD...",
  "authDomain": "order-eat-repeat-xxxxx.firebaseapp.com",
  "projectId": "order-eat-repeat-xxxxx",
  "storageBucket": "order-eat-repeat-xxxxx.appspot.com",
  "messagingSenderId": "123456789",
  "appId": "1:123456789:web:abc123xyz"
}
```

### Добавить в Vercel

1. В Vercel Dashboard → твой проект
2. Settings → Environment Variables
3. Добавить переменные:

| Ключ | Значение |
|-----|---------|
| `VITE_FIREBASE_API_KEY` | `AIzaSyD...` |
| `VITE_FIREBASE_AUTH_DOMAIN` | `order-eat-repeat-xxxxx.firebaseapp.com` |
| `VITE_FIREBASE_PROJECT_ID` | `order-eat-repeat-xxxxx` |
| `VITE_FIREBASE_STORAGE_BUCKET` | `order-eat-repeat-xxxxx.appspot.com` |
| `VITE_FIREBASE_MESSAGING_SENDER_ID` | `123456789` |
| `VITE_FIREBASE_APP_ID` | `1:123456789:web:abc123xyz` |
| `VITE_WHATSAPP_PHONE` | `972500000000` |

**Важно:** Префикс `VITE_` необходим! Иначе переменные не будут доступны клиенту.

---

## Этап 4: Обновить код для использования переменных

### В `src/lib/firebase.ts` (или где инициализируется Firebase)

**Было:**
```tsx
import firebaseConfig from '../firebase-applet-config.json';

const app = initializeApp(firebaseConfig);
```

**Должно быть:**
```tsx
const firebaseConfig = {
  apiKey: import.meta.env.VITE_FIREBASE_API_KEY,
  authDomain: import.meta.env.VITE_FIREBASE_AUTH_DOMAIN,
  projectId: import.meta.env.VITE_FIREBASE_PROJECT_ID,
  storageBucket: import.meta.env.VITE_FIREBASE_STORAGE_BUCKET,
  messagingSenderId: import.meta.env.VITE_FIREBASE_MESSAGING_SENDER_ID,
  appId: import.meta.env.VITE_FIREBASE_APP_ID,
};

const app = initializeApp(firebaseConfig);
```

### Обновить `.gitignore`

Убедиться что `firebase-applet-config.json` там (чтобы не залить на GitHub):

```
# .gitignore
firebase-applet-config.json
.env.local
.env.*.local
```

---

## Этап 5: Задеплойить

### Способ 1: Автоматический деплой (рекомендуется)

Просто запуши в GitHub:

```bash
git add .
git commit -m "Add Vercel deployment configuration"
git push origin main
```

Vercel **автоматически** заметит push и начнёт собирать проект. Можно отслеживать в Vercel Dashboard → Deployments.

### Способ 2: Ручной деплой через CLI

```bash
# Установить Vercel CLI
npm install -g vercel

# Залогиниться
vercel login

# Задеплойить
vercel
# Следовать подсказкам

# Для production (если это не первый деплой)
vercel --prod
```

---

## Этап 6: Проверить деплой

### URL проекта

После завершения деплоя, Vercel предоставит URL типа:
```
https://order-eat-repeat.vercel.app
```

### Проверка функциональности

1. Открыть сайт на URL
2. Проверить:
   - [ ] Меню загружается с Firestore
   - [ ] Картинки видны
   - [ ] Можно нажать на товар → открывается модалка
   - [ ] Кнопка "🗄️ База данных" работает → открывается админка
   - [ ] Кнопка WhatsApp работает
   - [ ] Нет ошибок в консоли (F12 → Console)

### Проверка пустой админки

1. Нажать "🗄️ База данных"
2. Должна открыться админка
3. Если сообщение "Товаров пока нет" — это нормально (Firestore пустой)
4. Добавить первый товар через админку → должен появиться на сайте

---

## Этап 7: Настроить собственный домен (опционально)

Если хочешь `order-eat-repeat.com` вместо `order-eat-repeat.vercel.app`:

### На Vercel

1. Project Settings → Domains
2. Нажать "Add"
3. Ввести домен `order-eat-repeat.com`
4. Vercel покажет DNS records для добавления

### На регистраторе домена (GoDaddy, Namecheap и т.д.)

1. Перейти в DNS настройки домена
2. Добавить записи как указано на Vercel:
   - Type: `CNAME`
   - Name: `www`
   - Value: `cname.vercel-dns.com`

3. Или использовать Vercel Nameservers:
   - `ns1.vercel-dns.com`
   - `ns2.vercel-dns.com`
   - `ns3.vercel-dns.com`

**Ждать 24-48 часов для распространения DNS.**

---

## Этап 8: Настроить автоматический деплой на каждый push

Это уже сделано автоматически в Vercel.

Каждый раз когда ты пушишь в `main`:
1. GitHub → Vercel вебхук
2. Vercel начинает собирать проект
3. После успеха → автоматический деплой на `vercel.app`

Можно отслеживать в Vercel Dashboard → Deployments.

---

## Команды для быстрого запуска

### Локальная разработка

```bash
npm run dev
# http://localhost:5173
```

### Сборка для продакшена (локально)

```bash
npm run build
npm run preview
```

### Добавить изменения и задеплойить

```bash
git add .
git commit -m "Your commit message"
git push origin main

# Vercel автоматически задеплойит
# Проверить статус на https://vercel.com/dashboard
```

---

## 🐛 Решение частых проблем

### Проблема: "Cannot find module 'firebase'"

**Решение:**
```bash
npm install
npm run build
```

Убедиться что `firebase` в package.json.

### Проблема: "VITE_FIREBASE_API_KEY is undefined"

**Решение:**
1. Vercel Dashboard → Settings → Environment Variables
2. Проверить что все переменные добавлены
3. Нажать "Redeploy" в Deployments
4. Убедиться что используется `import.meta.env.VITE_*`

### Проблема: Build fails с "Cannot find .firebaserc"

**Решение:** Убедиться что `.firebaserc` в `.gitignore`:
```bash
echo ".firebaserc" >> .gitignore
git add .gitignore
git commit -m "Add .firebaserc to gitignore"
git push
```

### Проблема: Картинки из Firestore не загружаются

**Проверить:**
1. URL картинки правильный
2. Firebase Storage публичный (Security Rules позволяют чтение)
3. Картинка не слишком большая (> 5MB?)

### Проблема: Vercel деплойится медленно

**Что попробовать:**
1. Проверить Build logs (Deployments → logs)
2. Кэш: Settings → Git → Clear Build Cache
3. Убедиться что .next/node_modules не залиты на GitHub

---

## 📊 Настройка мониторинга

### Analytics

1. Vercel Dashboard → Analytics
2. Включить "Web Analytics"
3. Vercel автоматически отслеживает:
   - Page load time
   - Core Web Vitals
   - User interactions

### Error Tracking

1. Settings → Error Tracking
2. Получать уведомления об ошибках в боте (Slack, Discord и т.д.)

---

## 🔒 Безопасность

### Убедиться что:

- [ ] `firebase-applet-config.json` в `.gitignore`
- [ ] `.env.local` в `.gitignore`
- [ ] Никаких API ключей в коде (только переменные окружения)
- [ ] Firebase Rules позволяют только нужные операции
- [ ] Vercel Environment Variables только для доверяемых хостов

### Firebase Security Rules

```javascript
rules_version = '2';
service cloud.firestore {
  match /databases/{database}/documents {
    // Публичное чтение для всех
    match /{document=**} {
      allow read: if true;
    }
    
    // Запись только аутентифицированным (позже настроишь)
    match /{document=**} {
      allow write: if request.auth != null;
    }
  }
}
```

---

## 🎉 Готово!

Сайт теперь доступен на:
```
https://order-eat-repeat.vercel.app
```

Каждый push в GitHub → автоматический деплой на Vercel ✨

**Следующие шаги:**
1. Добавить первый товар через админку
2. Загрузить картинки
3. Поделиться ссылкой с клиентом
4. Когда всё готово → настроить собственный домен

---

## 📞 Помощь

Если что-то не работает:

1. Проверить Vercel Build Logs
2. Проверить Browser Console (F12)
3. Проверить Firebase Rules и конфиги
4. Перезагрузить страницу (Ctrl+Shift+R)

Остальное — гугли или пиши в поддержку Vercel/Firebase! 🚀

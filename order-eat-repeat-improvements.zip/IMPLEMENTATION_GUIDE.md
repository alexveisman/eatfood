# 🛠️ Гайд по внедрению улучшений

## Что мы улучшили

1. **ProductCard.tsx** — мобильный дизайн (картинки, кнопки, текст)
2. **HorizontalFoodGallery.tsx** — картинки на мобильном не переполняют
3. **AdminProductManager.tsx** — drag-drop для фото, лучшая форма
4. **Общие** — фиксы для скролла, overflow, safe areas

---

## 📝 План внедрения

### Шаг 1: Скопировать обновлённые компоненты

Файлы в `/outputs/`:
- `ProductCard.tsx.improved` → `src/components/ProductCard.tsx`
- `HorizontalFoodGallery.tsx.improved` → `src/components/HorizontalFoodGallery.tsx`
- `AdminProductManager.improved.tsx` → `src/components/AdminProductManager.tsx`

### Шаг 2: Проверить импорты

Новые компоненты используют те же зависимости, что и старые:
- `lucide-react` — иконки (уже есть)
- `react` — основа (уже есть)
- `tailwindcss` — стили (уже есть)

Никаких новых npm пакетов не требуется.

### Шаг 3: Протестировать локально

```bash
cd order-eat-repeat-main
npm run dev
# Откроется http://localhost:5173

# CHECKLIST:
# [ ] На мобильном (375px) сайт не обрезается
# [ ] Картинки в карточках не слишком узкие/широкие
# [ ] Кнопки хорошо видны и легко нажимаются (не < 44px)
# [ ] Горизонтальная галерея не создаёт горизонтальный скролл
# [ ] Админка открывается на мобильном
# [ ] Можно перетащить фото в админку (drag-drop)
# [ ] Модалка админки закрывается нажатием на X
```

### Шаг 4: Загрузить на Vercel

```bash
git add .
git commit -m "feat: improve mobile design and admin panel"
git push origin main
```

Vercel автоматически задеплойит изменения.

### Шаг 5: Проверить на реальном телефоне

Открыть https://order-eat-repeat.vercel.app на iPhone и Android.

Проверить:
- [ ] На iPhone с нотчем (notch) контент не обрезается
- [ ] На Android с выступающей системной панелью (navigation bar) работает
- [ ] Touch события работают нормально
- [ ] Нет janky скроллов

---

## 🔧 Детальные изменения

### ProductCard.tsx

**Было:**
```tsx
className="relative aspect-[16/10] sm:aspect-[16/11]"  // На мобильном слишком широко
className="w-7 h-7 sm:w-7.5 sm:h-7.5"  // 28px на мобильном — мало
className="text-xs sm:text-sm"  // 12px на мобильном — мелко
```

**Стало:**
```tsx
className="relative aspect-[4/5] sm:aspect-[16/11]"  // На мобильном квадрат (близко к вертикали)
className="w-9 h-9 sm:w-8 sm:h-8"  // 36px на мобильном — нормально
className="text-sm sm:text-base"  // 14px на мобильном — читаемо

// Плюс добавлены srcSet и sizes для адаптивных картинок
srcSet={`
  ${product.image}?w=400 400w,
  ${product.image}?w=800 800w
`}
sizes="(max-width: 640px) 100vw, (max-width: 1024px) 50vw, 25vw"
```

### HorizontalFoodGallery.tsx

**Было:**
```tsx
className="flex-none w-[200px] sm:w-[250px] h-[140px] sm:h-[170px]"
// На 375px экране: 200px картинка + gap + padding = переполнение

className="gap-3 sm:gap-4.5"  // 12px gap, слишком много на мобильном
```

**Стало:**
```tsx
className="flex-none w-[160px] sm:w-[240px] h-[120px] sm:h-[170px]"
// На 375px экране: 160px + gap + padding = OK, не переполняет

className="gap-2 sm:gap-4"  // 8px gap на мобильном, нормально

// Плюс добавлены srcSet и sizes
srcSet={`
  ${item.image}?w=320 320w,
  ${item.image}?w=480 480w
`}
sizes="(max-width: 640px) 160px, 240px"
```

### AdminProductManager.tsx

**Новое:**
- Drag-drop зона для загрузки нескольких фото одновременно
- Превью фото перед загрузкой (сетка миниатюр)
- Кнопка удаления отдельных фото
- Progress bar при загрузке
- Фиксированная модалка (не обрезается на мобильном)
- Третья вкладка "Тексты сайта" (placeholder для будущего)
- `document.body.overflow = 'hidden'` при открытии (чтобы страница позади не скроллилась)
- Лучшая подвижность на телефоне (modal прилипает к низу, а не в центре)

**Было:**
```tsx
// Одиночная загрузка
<input type="file" accept="image/*" onChange={handleFileUpload} />

// Модалка фиксированная в центре
<div className="... fixed inset-0 z-50 flex items-center justify-center">
  <div className="... w-[600px]">  // На мобильном не влезает!
```

**Стало:**
```tsx
// Множественная загрузка + drag-drop
<div
  onDragEnter={handleGalleryDrag}
  onDragLeave={handleGalleryDrag}
  onDragOver={handleGalleryDrag}
  onDrop={handleGalleryDrop}
  className="border-2 border-dashed rounded-lg"
>
  {/* Drag-drop зона */}
  <input type="file" multiple accept="image/*" onChange={handleGalleryFileSelect} />
</div>

// Модалка адаптивная
<div className="... fixed inset-0 z-50 flex items-end sm:items-center">
  <div className="... w-full sm:w-[90%] md:w-[800px] rounded-t-2xl sm:rounded-2xl">
    // На мобильном: полная ширина, прилипает к низу
    // На desktop: 800px, в центре
```

---

## 🧪 Тестирование мобильной вёрстки

### Chrome DevTools
1. F12 → Device toolbar (Ctrl+Shift+M на Windows, Cmd+Shift+M на Mac)
2. Выбрать "iPhone 12" или "Galaxy S21"
3. Проверить:
   - Картинки не обрезаются
   - Текст читаемый (не мелкий)
   - Кнопки большие и удобно нажимаются
   - Нет горизонтального скролла

### iPhone (реальное устройство)
1. Открыть Safari
2. https://order-eat-repeat.vercel.app
3. Проверить:
   - Контент не обрезается (notch, safe areas)
   - Герой видно целиком
   - Картинки загружаются
   - Админка открывается

### Android (реальное устройство)
1. Открыть Chrome
2. https://order-eat-repeat.vercel.app
3. Проверить:
   - Контент не обрезается (навигационная панель)
   - Скролл smooth
   - Картинки не теряют качество

---

## 📊 Размеры экранов для тестирования

| Устройство | Ширина | Высота | Пиксельное соотношение |
|-----------|---------|---------|----------------------|
| iPhone SE | 375px | 667px | 2 |
| iPhone 12 | 390px | 844px | 3 |
| iPhone 14 Pro | 393px | 852px | 3 |
| Samsung S21 | 360px | 800px | 2.63 |
| iPad | 768px | 1024px | 2 |
| Desktop | 1920px | 1080px | 1 |

---

## 🚀 Оптимизация производительности (опционально)

После внедрения улучшений, можно добавить:

### 1. Lazy Loading для картинок
Уже есть `loading="lazy"`, но можно добавить Intersection Observer:

```tsx
import { useEffect, useRef, useState } from 'react';

const ImageWithLazyLoad: React.FC = () => {
  const imgRef = useRef<HTMLImageElement>(null);
  const [isLoaded, setIsLoaded] = useState(false);

  useEffect(() => {
    const observer = new IntersectionObserver(
      entries => {
        if (entries[0].isIntersecting) {
          setIsLoaded(true);
          observer.disconnect();
        }
      },
      { threshold: 0.1 }
    );

    if (imgRef.current) observer.observe(imgRef.current);
    return () => observer.disconnect();
  }, []);

  return (
    <img
      ref={imgRef}
      src={isLoaded ? src : 'data:image/svg+xml,%3Csvg...'} // placeholder
      alt={alt}
    />
  );
};
```

### 2. Image Optimization через CDN
Firebase Storage → Imagekit.io CDN:

```tsx
const imageUrl = `https://ik.imagekit.io/YOUR_ID/${photoId}`;
<img src={`${imageUrl}?tr=w-400,q-75,f-webp`} />
```

### 3. Critical CSS Inlining
Для быстрой загрузки "above the fold":

```tsx
// vite.config.ts
import { inlineCSS } from 'vite-plugin-inline-css';

export default {
  plugins: [
    inlineCSS({ inline: ['hero', 'header'] })
  ]
};
```

---

## 🐛 Возможные проблемы и решения

### Проблема: Картинки не загружаются с Firebase Storage

**Причина:** Неправильный URL или CORS

**Решение:**
```bash
# В Firebase Console → Storage → Rules
allow read: if request.auth != null || true;  // Общедоступное чтение
```

### Проблема: Админка открывается медленно

**Причина:** Большой размер компонента или медленная компрессия изображения

**Решение:** Добавить прогресс-бар (уже есть в улучшенной версии)

```tsx
{uploadProgress > 0 && uploadProgress < 100 && (
  <div className="mt-4">
    <div className="w-full bg-[#E8E2D9] rounded-full h-2">
      <div
        className="bg-[#D97706] h-full rounded-full transition-all"
        style={{ width: `${uploadProgress}%` }}
      />
    </div>
  </div>
)}
```

### Проблема: На iPhone 12 Pro Max (430px) текст не читаемый

**Причина:** Текст слишком мелкий

**Решение:** Используй `clamp()` для fluid typography:

```tsx
className="text-[clamp(13px, 3vw, 16px)]"  // Между 13px и 16px, зависит от ширины экрана
```

### Проблема: Горизонтальный скролл на мобильном

**Причина:** overflow на какого-то элемента

**Решение:**
```bash
# В Chrome DevTools:
# 1. Inspect element
# 2. Breadcrumbs → найти <div> с max-width или width: 100vw
# 3. Изменить на max-width: 100% или width: 100%
```

---

## ✅ Финальный чек-лист

Перед тем как считать готовым:

- [ ] Все файлы скопированы и заменены
- [ ] `npm install` выполнен (зависимостей не добавилось)
- [ ] `npm run dev` работает без ошибок
- [ ] На мобильном телефоне проверены все экраны:
  - [ ] Героя видно целиком
  - [ ] Меню категорий свайпается
  - [ ] Карточки товаров выглядят хорошо
  - [ ] Галерея не создаёт горизонтальный скролл
  - [ ] Кнопки большие и нажимаются легко
  - [ ] Админка открывается и можно загрузить фото
- [ ] На desktop сайт выглядит не хуже чем было
- [ ] Google PageSpeed Insights > 80 на мобильном
- [ ] Нет консольных ошибок (F12 → Console)

---

## 🎓 Полезные ссылки

- [Tailwind Responsive Design](https://tailwindcss.com/docs/responsive-design)
- [Mobile Best Practices](https://web.dev/mobile-best-practices/)
- [iOS Safe Areas](https://webkit.org/blog/7929/designing-websites-for-iphone-x/)
- [Touch Target Size](https://www.w3.org/WAI/WCAG21/Understanding/target-size.html)

---

Готово! 🚀 Если будут вопросы — пиши.

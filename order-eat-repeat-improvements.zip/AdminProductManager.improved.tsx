import React, { useState, useEffect } from 'react';
import {
  X,
  Upload,
  Plus,
  Trash2,
  Edit2,
  Check,
  Image as ImageIcon,
  Sparkles,
  Database,
  RefreshCw,
  FolderOpen,
  AlertCircle
} from 'lucide-react';
import { Product, CategoryId } from '../types';
import { CATEGORIES } from '../data/menuData';
import {
  saveProductToFirestore,
  deleteProductFromFirestore,
  saveGalleryPhotoToFirestore,
  deleteGalleryPhotoFromFirestore,
  GalleryPhotoItem
} from '../services/productService';
import { compressAndEncodeImage } from '../utils/imageCompressor';

interface AdminProductManagerProps {
  isOpen: boolean;
  onClose: () => void;
  products: Product[];
  galleryPhotos: GalleryPhotoItem[];
}

export const AdminProductManager: React.FC<AdminProductManagerProps> = ({
  isOpen,
  onClose,
  products,
  galleryPhotos
}) => {
  const [activeTab, setActiveTab] = useState<'menu' | 'gallery' | 'texts'>('menu');
  const [selectedProduct, setSelectedProduct] = useState<Product | null>(null);
  const [isEditing, setIsEditing] = useState(false);
  const [isSaving, setIsSaving] = useState(false);
  const [saveSuccess, setSaveSuccess] = useState(false);
  const [dragActive, setDragActive] = useState(false);

  // Form states for Product
  const [name, setName] = useState('');
  const [category, setCategory] = useState<CategoryId>('dumplings_mains');
  const [price, setPrice] = useState<number>(50);
  const [unit, setUnit] = useState('кг');
  const [shortDescription, setShortDescription] = useState('');
  const [fullDescription, setFullDescription] = useState('');
  const [imagePreview, setImagePreview] = useState('');
  const [availableFillingsText, setAvailableFillingsText] = useState('');
  const [cookingOptionsText, setCookingOptionsText] = useState('');
  const [uploadProgress, setUploadProgress] = useState(0);

  // Gallery photo form state
  const [galleryTitle, setGalleryTitle] = useState('');
  const [galleryCategory, setGalleryCategory] = useState('Пельмени');
  const [galleryImagePreviews, setGalleryImagePreviews] = useState<string[]>([]);
  const [galleryFiles, setGalleryFiles] = useState<File[]>([]);

  const [errorMessage, setErrorMessage] = useState<string | null>(null);

  // Закрывать админку при нажатии на body скролл
  useEffect(() => {
    if (isOpen) {
      document.body.style.overflow = 'hidden';
    }
    return () => {
      document.body.style.overflow = 'auto';
    };
  }, [isOpen]);

  if (!isOpen) return null;

  // ============================================
  // PRODUCT HANDLERS
  // ============================================

  const handleStartEdit = (prod: Product) => {
    setSelectedProduct(prod);
    setName(prod.name);
    setCategory(prod.category);
    setPrice(prod.price);
    setUnit(prod.unit);
    setShortDescription(prod.shortDescription || '');
    setFullDescription(prod.fullDescription || '');
    setImagePreview(prod.image || '');
    setAvailableFillingsText(prod.availableFillings?.join('\n') || '');
    setCookingOptionsText(prod.cookingOptions?.join('\n') || '');
    setErrorMessage(null);
    setIsEditing(true);
  };

  const handleStartCreate = () => {
    setSelectedProduct(null);
    setName('');
    setCategory('dumplings_mains');
    setPrice(50);
    setUnit('кг');
    setShortDescription('');
    setFullDescription('');
    setImagePreview('');
    setAvailableFillingsText('');
    setCookingOptionsText('');
    setErrorMessage(null);
    setIsEditing(true);
  };

  const handleProductFileUpload = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    try {
      setIsSaving(true);
      const compressed = await compressAndEncodeImage(file);
      setImagePreview(compressed);
      setErrorMessage(null);
    } catch (err) {
      setErrorMessage('Ошибка при загрузке фото: ' + (err instanceof Error ? err.message : 'Неизвестная ошибка'));
    } finally {
      setIsSaving(false);
    }
  };

  const handleSaveProduct = async () => {
    if (!name.trim()) {
      setErrorMessage('Укажите название товара');
      return;
    }
    if (!imagePreview) {
      setErrorMessage('Загрузите фото товара');
      return;
    }

    try {
      setIsSaving(true);
      const productData: Product = {
        id: selectedProduct?.id || `prod-${Date.now()}`,
        name,
        category,
        price,
        unit,
        shortDescription,
        fullDescription,
        image: imagePreview,
        availableFillings: availableFillingsText
          .split('\n')
          .map(f => f.trim())
          .filter(Boolean),
        cookingOptions: cookingOptionsText
          .split('\n')
          .map(c => c.trim())
          .filter(Boolean),
        weight: '',
        minQuantity: 1,
        stepQuantity: 1,
        isBestseller: false,
        badge: undefined,
        ingredients: [],
        gallery: [imagePreview]
      };

      await saveProductToFirestore(productData);
      setSaveSuccess(true);
      setTimeout(() => {
        setSaveSuccess(false);
        setIsEditing(false);
      }, 1500);
    } catch (err) {
      setErrorMessage('Ошибка при сохранении: ' + (err instanceof Error ? err.message : 'Неизвестная ошибка'));
    } finally {
      setIsSaving(false);
    }
  };

  const handleDeleteProduct = async (prodId: string) => {
    if (!confirm('Вы уверены? Товар будет удалён навсегда.')) return;

    try {
      await deleteProductFromFirestore(prodId);
    } catch (err) {
      setErrorMessage('Ошибка при удалении: ' + (err instanceof Error ? err.message : 'Неизвестная ошибка'));
    }
  };

  // ============================================
  // GALLERY HANDLERS - с drag-drop!
  // ============================================

  const handleGalleryDrag = (e: React.DragEvent<HTMLDivElement>) => {
    e.preventDefault();
    e.stopPropagation();
    if (e.type === 'dragenter' || e.type === 'dragover') {
      setDragActive(true);
    } else if (e.type === 'dragleave') {
      setDragActive(false);
    }
  };

  const handleGalleryDrop = async (e: React.DragEvent<HTMLDivElement>) => {
    e.preventDefault();
    e.stopPropagation();
    setDragActive(false);

    const files = Array.from(e.dataTransfer.files);
    const imageFiles = files.filter(f => f.type.startsWith('image/'));

    if (imageFiles.length === 0) {
      setErrorMessage('Пожалуйста, перетащите только изображения');
      return;
    }

    await processGalleryFiles(imageFiles);
  };

  const handleGalleryFileSelect = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const files = Array.from(e.target.files || []);
    await processGalleryFiles(files);
  };

  const processGalleryFiles = async (files: File[]) => {
    try {
      setIsSaving(true);
      const previews: string[] = [];
      const newFiles: File[] = [];

      for (let i = 0; i < files.length; i++) {
        const file = files[i];
        setUploadProgress(Math.round((i / files.length) * 100));

        const compressed = await compressAndEncodeImage(file);
        previews.push(compressed);
        newFiles.push(file);
      }

      setGalleryImagePreviews(prev => [...prev, ...previews]);
      setGalleryFiles(prev => [...prev, ...newFiles]);
      setUploadProgress(0);
      setErrorMessage(null);
    } catch (err) {
      setErrorMessage('Ошибка при обработке фото: ' + (err instanceof Error ? err.message : 'Неизвестная ошибка'));
    } finally {
      setIsSaving(false);
    }
  };

  const removeGalleryPreview = (index: number) => {
    setGalleryImagePreviews(prev => prev.filter((_, i) => i !== index));
    setGalleryFiles(prev => prev.filter((_, i) => i !== index));
  };

  const handleSaveGalleryPhotos = async () => {
    if (galleryImagePreviews.length === 0) {
      setErrorMessage('Добавьте хотя бы одно фото');
      return;
    }

    try {
      setIsSaving(true);
      for (const image of galleryImagePreviews) {
        const photoData: GalleryPhotoItem = {
          id: `gallery-${Date.now()}-${Math.random()}`,
          title: galleryTitle || 'Блюдо',
          category: galleryCategory,
          image
        };
        await saveGalleryPhotoToFirestore(photoData);
      }

      setSaveSuccess(true);
      setTimeout(() => {
        setSaveSuccess(false);
        setGalleryImagePreviews([]);
        setGalleryFiles([]);
        setGalleryTitle('');
      }, 1500);
    } catch (err) {
      setErrorMessage('Ошибка при загрузке фото: ' + (err instanceof Error ? err.message : 'Неизвестная ошибка'));
    } finally {
      setIsSaving(false);
    }
  };

  const handleDeleteGalleryPhoto = async (photoId: string) => {
    try {
      await deleteGalleryPhotoFromFirestore(photoId);
    } catch (err) {
      setErrorMessage('Ошибка при удалении: ' + (err instanceof Error ? err.message : 'Неизвестная ошибка'));
    }
  };

  // ============================================
  // RENDER
  // ============================================

  return (
    <>
      {/* Backdrop */}
      <div
        onClick={onClose}
        className="fixed inset-0 bg-black/40 z-40 transition-opacity"
      />

      {/* Modal */}
      <div className="fixed inset-0 z-50 flex items-end sm:items-center justify-center p-0 sm:p-4">
        <div className="w-full sm:w-[90%] md:w-[800px] max-h-[90vh] bg-white rounded-t-2xl sm:rounded-2xl shadow-2xl overflow-hidden flex flex-col">
          {/* Header */}
          <div className="flex items-center justify-between p-4 sm:p-6 border-b border-[#E8E2D9] bg-gradient-to-r from-[#FEF3E2] to-[#FDFBF7]">
            <div className="flex items-center gap-2">
              <Database className="w-5 h-5 text-[#D97706]" />
              <h2 className="text-lg sm:text-xl font-bold text-[#4A3728]">
                {activeTab === 'menu' ? 'Управление меню' : activeTab === 'gallery' ? 'Галерея фото' : 'Тексты сайта'}
              </h2>
            </div>
            <button
              onClick={onClose}
              className="p-2 hover:bg-white/50 rounded-lg transition-colors cursor-pointer"
              aria-label="Закрыть"
            >
              <X className="w-5 h-5 text-[#6D5A4C]" />
            </button>
          </div>

          {/* Tabs */}
          <div className="flex gap-0 px-0 border-b border-[#E8E2D9] overflow-x-auto">
            {[
              { id: 'menu', label: '🍽️ Меню', icon: '🍽️' },
              { id: 'gallery', label: '📸 Галерея', icon: '📸' },
              { id: 'texts', label: '✏️ Тексты', icon: '✏️' }
            ].map(tab => (
              <button
                key={tab.id}
                onClick={() => {
                  setActiveTab(tab.id as any);
                  setIsEditing(false);
                }}
                className={`px-4 py-3 font-semibold text-sm whitespace-nowrap transition-colors border-b-2 ${
                  activeTab === tab.id
                    ? 'border-[#D97706] text-[#D97706]'
                    : 'border-transparent text-[#6D5A4C] hover:text-[#4A3728]'
                }`}
              >
                {tab.label}
              </button>
            ))}
          </div>

          {/* Content - Scrollable */}
          <div className="flex-1 overflow-y-auto p-4 sm:p-6 space-y-4">
            {/* Error Message */}
            {errorMessage && (
              <div className="p-4 bg-red-50 border border-red-200 rounded-lg flex gap-3 items-start">
                <AlertCircle className="w-5 h-5 text-red-600 flex-shrink-0 mt-0.5" />
                <div className="text-sm text-red-700">{errorMessage}</div>
              </div>
            )}

            {/* Success Message */}
            {saveSuccess && (
              <div className="p-4 bg-emerald-50 border border-emerald-200 rounded-lg flex gap-3 items-center">
                <Check className="w-5 h-5 text-emerald-600" />
                <div className="text-sm text-emerald-700">Сохранено успешно! ✨</div>
              </div>
            )}

            {/* TAB: MENU */}
            {activeTab === 'menu' && (
              <div className="space-y-4">
                {!isEditing ? (
                  <>
                    {/* Product List */}
                    <button
                      onClick={handleStartCreate}
                      className="w-full py-3 px-4 bg-[#D97706] hover:bg-[#C66D00] text-white font-bold rounded-lg flex items-center justify-center gap-2 transition-colors cursor-pointer"
                    >
                      <Plus className="w-4 h-4" />
                      Создать новый товар
                    </button>

                    <div className="space-y-2 max-h-[500px] overflow-y-auto">
                      {products.length === 0 ? (
                        <p className="text-center text-[#6D5A4C] py-8">Товаров пока нет</p>
                      ) : (
                        products.map(prod => (
                          <div
                            key={prod.id}
                            className="p-3 bg-[#FEF3E2] rounded-lg border border-[#E8E2D9] flex items-center justify-between gap-3"
                          >
                            <div className="flex items-center gap-3 flex-1 min-w-0">
                              {prod.image && (
                                <img
                                  src={prod.image}
                                  alt={prod.name}
                                  className="w-12 h-12 rounded object-cover flex-shrink-0"
                                />
                              )}
                              <div className="min-w-0">
                                <h4 className="font-semibold text-sm text-[#382A1E] truncate">
                                  {prod.name}
                                </h4>
                                <p className="text-xs text-[#6D5A4C]">
                                  {prod.price} ₪ / {prod.unit}
                                </p>
                              </div>
                            </div>
                            <div className="flex gap-2 flex-shrink-0">
                              <button
                                onClick={() => handleStartEdit(prod)}
                                className="p-2 bg-white hover:bg-[#D97706]/10 text-[#D97706] rounded-lg transition-colors cursor-pointer"
                                title="Редактировать"
                              >
                                <Edit2 className="w-4 h-4" />
                              </button>
                              <button
                                onClick={() => handleDeleteProduct(prod.id)}
                                className="p-2 bg-white hover:bg-red-50 text-red-600 rounded-lg transition-colors cursor-pointer"
                                title="Удалить"
                              >
                                <Trash2 className="w-4 h-4" />
                              </button>
                            </div>
                          </div>
                        ))
                      )}
                    </div>
                  </>
                ) : (
                  /* Product Edit Form */
                  <div className="space-y-4">
                    <div>
                      <label className="block text-xs font-bold text-[#4A3728] mb-1">
                        Название товара *
                      </label>
                      <input
                        type="text"
                        value={name}
                        onChange={e => setName(e.target.value)}
                        placeholder="Например: Пельмени ручной лепки"
                        className="w-full px-3 py-2 border border-[#E8E2D9] rounded-lg text-sm focus:outline-none focus:ring-2 focus:ring-[#D97706]"
                      />
                    </div>

                    <div className="grid grid-cols-2 gap-3">
                      <div>
                        <label className="block text-xs font-bold text-[#4A3728] mb-1">
                          Категория
                        </label>
                        <select
                          value={category}
                          onChange={e => setCategory(e.target.value as CategoryId)}
                          className="w-full px-3 py-2 border border-[#E8E2D9] rounded-lg text-sm focus:outline-none focus:ring-2 focus:ring-[#D97706]"
                        >
                          {CATEGORIES.map(cat => (
                            <option key={cat.id} value={cat.id}>
                              {cat.label}
                            </option>
                          ))}
                        </select>
                      </div>

                      <div>
                        <label className="block text-xs font-bold text-[#4A3728] mb-1">
                          Цена (₪)
                        </label>
                        <input
                          type="number"
                          value={price}
                          onChange={e => setPrice(Number(e.target.value))}
                          className="w-full px-3 py-2 border border-[#E8E2D9] rounded-lg text-sm focus:outline-none focus:ring-2 focus:ring-[#D97706]"
                        />
                      </div>
                    </div>

                    <div>
                      <label className="block text-xs font-bold text-[#4A3728] mb-1">
                        Единица (кг, шт, пак и т.д.)
                      </label>
                      <input
                        type="text"
                        value={unit}
                        onChange={e => setUnit(e.target.value)}
                        placeholder="кг"
                        className="w-full px-3 py-2 border border-[#E8E2D9] rounded-lg text-sm focus:outline-none focus:ring-2 focus:ring-[#D97706]"
                      />
                    </div>

                    <div>
                      <label className="block text-xs font-bold text-[#4A3728] mb-1">
                        Краткое описание
                      </label>
                      <textarea
                        value={shortDescription}
                        onChange={e => setShortDescription(e.target.value)}
                        placeholder="Что-нибудь короткое и аппетитное"
                        rows={2}
                        className="w-full px-3 py-2 border border-[#E8E2D9] rounded-lg text-sm focus:outline-none focus:ring-2 focus:ring-[#D97706]"
                      />
                    </div>

                    <div>
                      <label className="block text-xs font-bold text-[#4A3728] mb-1">
                        Полное описание
                      </label>
                      <textarea
                        value={fullDescription}
                        onChange={e => setFullDescription(e.target.value)}
                        placeholder="Расскажите подробнее о ингредиентах, способе приготовления и т.д."
                        rows={3}
                        className="w-full px-3 py-2 border border-[#E8E2D9] rounded-lg text-sm focus:outline-none focus:ring-2 focus:ring-[#D97706]"
                      />
                    </div>

                    <div>
                      <label className="block text-xs font-bold text-[#4A3728] mb-2">
                        Фото товара * {isSaving && `(загрузка ${uploadProgress}%)`}
                      </label>
                      <div className="flex gap-3">
                        <label className="flex-1 border-2 border-dashed border-[#D97706] rounded-lg p-4 cursor-pointer hover:bg-[#FEF3E2] transition-colors text-center">
                          <ImageIcon className="w-5 h-5 mx-auto mb-2 text-[#D97706]" />
                          <span className="text-xs text-[#D97706] font-semibold">
                            Выберите фото
                          </span>
                          <input
                            type="file"
                            accept="image/*"
                            onChange={handleProductFileUpload}
                            disabled={isSaving}
                            className="hidden"
                          />
                        </label>
                        {imagePreview && (
                          <img
                            src={imagePreview}
                            alt="Preview"
                            className="w-24 h-24 object-cover rounded-lg border border-[#E8E2D9]"
                          />
                        )}
                      </div>
                    </div>

                    <div>
                      <label className="block text-xs font-bold text-[#4A3728] mb-1">
                        Начинки (по одной на строке)
                      </label>
                      <textarea
                        value={availableFillingsText}
                        onChange={e => setAvailableFillingsText(e.target.value)}
                        placeholder="С творогом&#10;С картофелем&#10;С яйцом"
                        rows={3}
                        className="w-full px-3 py-2 border border-[#E8E2D9] rounded-lg text-sm font-mono focus:outline-none focus:ring-2 focus:ring-[#D97706]"
                      />
                    </div>

                    <div className="flex gap-2 pt-4">
                      <button
                        onClick={handleSaveProduct}
                        disabled={isSaving}
                        className="flex-1 py-2 px-4 bg-[#D97706] hover:bg-[#C66D00] disabled:opacity-50 text-white font-bold rounded-lg flex items-center justify-center gap-2 transition-colors cursor-pointer"
                      >
                        {isSaving ? <RefreshCw className="w-4 h-4 animate-spin" /> : <Check className="w-4 h-4" />}
                        {isSaving ? 'Сохраняю...' : 'Сохранить'}
                      </button>
                      <button
                        onClick={() => setIsEditing(false)}
                        className="px-4 py-2 border border-[#E8E2D9] hover:bg-[#FEF3E2] text-[#4A3728] font-bold rounded-lg transition-colors cursor-pointer"
                      >
                        Отмена
                      </button>
                    </div>
                  </div>
                )}
              </div>
            )}

            {/* TAB: GALLERY */}
            {activeTab === 'gallery' && (
              <div className="space-y-4">
                {/* Drag-Drop Zone */}
                <div
                  onDragEnter={handleGalleryDrag}
                  onDragLeave={handleGalleryDrag}
                  onDragOver={handleGalleryDrag}
                  onDrop={handleGalleryDrop}
                  className={`border-2 border-dashed rounded-lg p-6 sm:p-8 text-center transition-all ${
                    dragActive
                      ? 'border-[#D97706] bg-[#FEF3E2]'
                      : 'border-[#E8E2D9] bg-[#FDFBF7]'
                  }`}
                >
                  <Upload className={`w-8 h-8 mx-auto mb-3 ${dragActive ? 'text-[#D97706]' : 'text-[#D97706]/50'}`} />
                  <p className="font-bold text-[#4A3728] mb-1">
                    Перетащите фото сюда
                  </p>
                  <p className="text-xs text-[#6D5A4C] mb-3">
                    или нажмите чтобы выбрать файлы
                  </p>
                  <label className="inline-block px-4 py-2 bg-[#D97706] hover:bg-[#C66D00] text-white rounded-lg text-sm font-bold cursor-pointer transition-colors">
                    Выбрать фото
                    <input
                      type="file"
                      multiple
                      accept="image/*"
                      onChange={handleGalleryFileSelect}
                      disabled={isSaving}
                      className="hidden"
                    />
                  </label>
                  {uploadProgress > 0 && uploadProgress < 100 && (
                    <div className="mt-4">
                      <div className="w-full bg-[#E8E2D9] rounded-full h-2">
                        <div
                          className="bg-[#D97706] h-full rounded-full transition-all"
                          style={{ width: `${uploadProgress}%` }}
                        />
                      </div>
                      <p className="text-xs text-[#6D5A4C] mt-2">{uploadProgress}%</p>
                    </div>
                  )}
                </div>

                {/* Thumbnails Grid */}
                {galleryImagePreviews.length > 0 && (
                  <div>
                    <h3 className="font-bold text-sm text-[#4A3728] mb-3">
                      {galleryImagePreviews.length} фото для загрузки
                    </h3>
                    <div className="grid grid-cols-3 sm:grid-cols-4 gap-2">
                      {galleryImagePreviews.map((preview, idx) => (
                        <div
                          key={idx}
                          className="relative group rounded-lg overflow-hidden border border-[#E8E2D9]"
                        >
                          <img
                            src={preview}
                            alt={`Preview ${idx}`}
                            className="w-full aspect-square object-cover"
                          />
                          <button
                            onClick={() => removeGalleryPreview(idx)}
                            className="absolute top-1 right-1 bg-red-500 hover:bg-red-600 text-white rounded-full p-1 opacity-0 group-hover:opacity-100 transition-opacity cursor-pointer"
                            title="Удалить"
                          >
                            <X className="w-3 h-3" />
                          </button>
                        </div>
                      ))}
                    </div>
                  </div>
                )}

                {/* Existing Gallery */}
                {galleryPhotos.length > 0 && (
                  <div>
                    <h3 className="font-bold text-sm text-[#4A3728] mb-3">
                      На сайте ({galleryPhotos.length})
                    </h3>
                    <div className="grid grid-cols-3 sm:grid-cols-4 gap-2 max-h-[300px] overflow-y-auto">
                      {galleryPhotos.map((photo) => (
                        <div
                          key={photo.id}
                          className="relative group rounded-lg overflow-hidden border border-[#E8E2D9]"
                        >
                          <img
                            src={photo.image}
                            alt={photo.title}
                            className="w-full aspect-square object-cover"
                          />
                          <button
                            onClick={() => handleDeleteGalleryPhoto(photo.id)}
                            className="absolute top-1 right-1 bg-red-500 hover:bg-red-600 text-white rounded-full p-1 opacity-0 group-hover:opacity-100 transition-opacity cursor-pointer"
                            title="Удалить"
                          >
                            <Trash2 className="w-3 h-3" />
                          </button>
                        </div>
                      ))}
                    </div>
                  </div>
                )}

                {/* Save Button */}
                {galleryImagePreviews.length > 0 && (
                  <button
                    onClick={handleSaveGalleryPhotos}
                    disabled={isSaving}
                    className="w-full py-3 px-4 bg-[#D97706] hover:bg-[#C66D00] disabled:opacity-50 text-white font-bold rounded-lg flex items-center justify-center gap-2 transition-colors cursor-pointer"
                  >
                    {isSaving ? <RefreshCw className="w-4 h-4 animate-spin" /> : <Check className="w-4 h-4" />}
                    {isSaving ? 'Загружаю фото...' : `Загрузить ${galleryImagePreviews.length} фото`}
                  </button>
                )}
              </div>
            )}

            {/* TAB: TEXTS - Coming Soon */}
            {activeTab === 'texts' && (
              <div className="text-center py-12">
                <Sparkles className="w-12 h-12 mx-auto mb-4 text-[#D97706]/30" />
                <h3 className="font-bold text-[#4A3728] mb-2">Редактирование текстов</h3>
                <p className="text-sm text-[#6D5A4C] mb-4">
                  Эта функция в разработке. Пока тексты можно менять через меню и описания товаров.
                </p>
                <p className="text-xs text-[#999] italic">
                  Скоро здесь можно будет менять заголовки, описания и другие тексты на сайте
                </p>
              </div>
            )}
          </div>
        </div>
      </div>
    </>
  );
};

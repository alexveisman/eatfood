# ⚡ Быстрая справка: Перенос Order-Eat-Repeat

## 📋 Что нужно сделать

### Сейчас (день 1)
1. **Перенести на Vercel** (2 часа)
   - Push на GitHub
   - Создать проект на Vercel
   - Добавить переменные Firebase
   - Задеплойить

2. **Внедрить улучшения кода** (1 час)
   - Скопировать 3 улучшенных файла:
     - `ProductCard.tsx.improved` → `src/components/ProductCard.tsx`
     - `HorizontalFoodGallery.tsx.improved` → `src/components/HorizontalFoodGallery.tsx`
     - `AdminProductManager.improved.tsx` → `src/components/AdminProductManager.tsx`
   - Push на GitHub (автоматический деплой)

### Потом (если нужно)
3. **Оптимизация CDN** (если медленная загрузка картинок)
4. **PWA** (установить как приложение)
5. **Платежи/Email** (интеграции)

---

## 🎯 Что получишь

| Что | Было | Будет |
|-----|------|-------|
| **Хостинг** | AI Studio | Vercel (быстрее) |
| **Домен** | .ai.studio | твой домен |
| **Админка** | базовая | drag-drop, preview |
| **Мобильный** | проблемы | оптимальный |
| **Картинки** | медленно | с srcSet/sizes |
| **Скоро выехать** | может быть | контролируешь ты |

---

## 📁 Файлы в /outputs/

```
outputs/
├── MIGRATION_PLAN.md                 ← Подробный план (ТЫ ЗДЕСЬ)
├── IMPLEMENTATION_GUIDE.md          ← Как применить улучшения
├── VERCEL_DEPLOYMENT.md             ← Как деплойить на Vercel
├── QUICK_SUMMARY.md                 ← Эта файл
├── ProductCard.tsx.improved         ← Улучшенный компонент карточки
├── HorizontalFoodGallery.tsx.improved   ← Улучшенная галерея
├── AdminProductManager.improved.tsx ← Улучшенная админка
└── order-eat-repeat-analysis/       ← Копия твоего проекта для анализа
```

---

## 🚀 Быстрый старт (10 минут)

### Командная строка

```bash
# 1. Подготовить git
cd order-eat-repeat-main
git init
git add .
git commit -m "Initial commit"
git remote add origin https://github.com/YOUR_USERNAME/order-eat-repeat.git
git push -u origin main

# 2. Открыть Vercel и создать проект
# vercel.com → "Add New" → "Project" → выбрать репо

# 3. Добавить переменные в Vercel
# Project Settings → Environment Variables → добавить Firebase конфиги

# 4. Обновить код для переменных
# Скопировать новый firebase.ts или обновить инициализацию

# 5. Скопировать улучшенные компоненты
cp ProductCard.tsx.improved src/components/ProductCard.tsx
cp HorizontalFoodGallery.tsx.improved src/components/HorizontalFoodGallery.tsx
cp AdminProductManager.improved.tsx src/components/AdminProductManager.tsx

# 6. Push (автоматический деплой на Vercel)
git add .
git commit -m "Improve mobile design and admin panel"
git push origin main

# 7. Проверить на https://order-eat-repeat.vercel.app
```

---

## ✨ Ключевые улучшения

### ProductCard
- ✅ Картинки (aspect-[4/5] вместо [16/10] на мобильном)
- ✅ Кнопки (36px вместо 28px — удобнее нажимать)
- ✅ Текст (14px вместо 12px — читаемо)
- ✅ Srcset/sizes для адаптивной загрузки

### HorizontalFoodGallery
- ✅ Картинки (160px вместо 200px на мобильном)
- ✅ Горизонтальный скролл не переполняет экран
- ✅ Srcset/sizes для быстрой загрузки

### AdminProductManager
- ✅ Drag-drop для нескольких фото
- ✅ Preview перед загрузкой
- ✅ Progress bar при загрузке
- ✅ Адаптивная модалка (на мобильном внизу, на desktop в центре)
- ✅ Вкладка для будущих "Текстов сайта"

---

## 🔥 Самое важное

**Три файла которые нужно заменить:**

1. `ProductCard.tsx.improved` → `src/components/ProductCard.tsx`
2. `HorizontalFoodGallery.tsx.improved` → `src/components/HorizontalFoodGallery.tsx`
3. `AdminProductManager.improved.tsx` → `src/components/AdminProductManager.tsx`

Остальное остаётся как есть!

---

## 🧪 Тестирование (10 минут)

```
Локально:
npm run dev
→ Открыть http://localhost:5173
→ Проверить на мобильном (Chrome DevTools: Ctrl+Shift+M)
→ Админка открывается, фото загружаются

На Vercel:
→ Открыть https://order-eat-repeat.vercel.app
→ Проверить на реальном телефоне
→ Всё работает? Great!
```

---

## 💰 Стоимость

| Сервис | Цена | Заметки |
|--------|------|---------|
| Vercel | $0 (free tier) | Достаточно для небольшого сайта |
| Firebase | $0 (Spark plan) | 50k reads/day, 20k writes/day |
| Домен | $10-15/год | namecheap.com, hostgator и т.д. |
| **Итого** | **~$1/месяц** | Дешево |

Free tier хватает месяцев на 6-12 односитного ресторана. Если вырастет — переходишь на платный план.

---

## 📞 Поддержка

### Если что-то не работает

1. **Локально ошибка** → посмотреть консоль (npm run dev)
2. **Vercel ошибка** → Vercel Dashboard → Deployments → logs
3. **Firebase ошибка** → Firebase Console → check rules
4. **На мобильном не видно** → Chrome DevTools responsive mode

### Полезные ссылки

- [Vercel Docs](https://vercel.com/docs)
- [Firebase Console](https://console.firebase.google.com)
- [Tailwind Docs](https://tailwindcss.com)
- [React Docs](https://react.dev)

---

## 🎯 Результат

Когда всё готово:

✅ Сайт на своём хостинге  
✅ Админка работает  
✅ Мобильный дизайн идеален  
✅ Картинки загружаются быстро  
✅ Можно редактировать меню в реальном времени  
✅ Клиент доволен  

---

## 📅 График

| День | Задача | Время |
|------|--------|-------|
| 1 | Vercel деплой + переменные | 2 часа |
| 1 | Внедрить улучшения кода | 1 час |
| 1 | Тестирование на мобильном | 1 час |
| 1 | Итого | 4 часа |
| 2 | Доп. оптимизация (опционально) | 2-3 часа |
| 3 | Настроить домен (опционально) | 1 час |

---

## ✅ Финальный чек-лист

Перед тем как считать готовым:

- [ ] Проект на GitHub
- [ ] Deплойнут на Vercel
- [ ] Firebase переменные добавлены
- [ ] 3 файла скопированы и заменены
- [ ] Локально работает (`npm run dev`)
- [ ] На Vercel работает (открыть URL)
- [ ] На мобильном телефоне проверено (iOS + Android)
- [ ] Картинки не обрезаются
- [ ] Кнопки хорошего размера
- [ ] Нет горизонтального скролла
- [ ] Админка работает
- [ ] Фото можно загружать через drag-drop
- [ ] Нет консольных ошибок (F12 → Console)
- [ ] Клиент одобрил

---

## 🎊 Готово!

Теперь твой сайт:
- На собственном хостинге
- Быстрый и адаптивный
- С удобной админкой
- Готов к росту

Поздравляю! 🎉

---

**Вопросы?** Пиши. Готов помочь с любым из этапов! 🚀
